<?php
header('Content-Type: text/html; charset=utf-8');

require("CurrentTable.class.php");
require("Table.class.php");
require("Generator.class.php");

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $host = trim(strip_tags($_POST["host"]));
    $login = trim(strip_tags($_POST["login"]));
    $password = trim(strip_tags($_POST["password"]));
    $base = trim(strip_tags($_POST["base"]));
    $table = trim(strip_tags($_POST["table"]));
    $number = (int)$_POST["number"];

    $dataObj = new CurrentTable($host, $login, $password, $base);
    $mes = $dataObj->setValues($table, $number);

    if($mes == TRUE){
        echo "Данные успешно сгенерированы и добавлены в таблицу $table";
    }
    else{
        echo "Возникла непредвиденная ошибка генерации либо добавления данных в таблицу $table";
    }
}
?>
