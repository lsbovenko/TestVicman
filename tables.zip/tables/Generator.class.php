<?php
class MyGenerator{
    public $connection;
    public $table;
    public $tableObj;

    function __construct($connection, $table){
        $this->connection = $connection;
        $this->table = $table;
        $this->tableObj = new Table($this->table, $this->connection);
        $this->tableObj->getInfo();
    }

    function generate(){

        $numberArray = array('0','1','2','3','4','5','6','7','8','9');
        $symbolArray = array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');

        foreach($this->tableObj->columns as $column){
            foreach($column as $key=>$value){
                if($key == "Field"){
                    $keyVal = $value;
                }
                if($key == "Type"){
                    if(stristr($value, 'int') == TRUE){
                        $resVal = "";
                        for($i=0; $i<5; $i++){
                            $resVal .= $numberArray[mt_rand(0, 9)];
                        }
                    }
                    if(stristr($value, 'char') == TRUE){
                        $resVal = "";
                        for($i=0; $i<10; $i++){
                            $resVal .= $symbolArray[mt_rand(0, 25)];
                        }
                     }
                    if(stristr($value, 'date') == TRUE){
                        $start = mktime(0,0,0,1,1,2010);
                        $end  = time();
                        $randomStamp = rand($start, $end);
                        $resVal = date('Y-m-d', $randomStamp);
                    }
                }
                if($key == "Key" && $value != null){
                    $sql = "SELECT COUNT(*) FROM " . $this->table . " WHERE " . $keyVal . " = '" . $resVal . "'";
                    $sqlRes = mysqli_query($this->connection, $sql);
                    $item = mysqli_fetch_row($sqlRes);
                    do{
                        if($item[0] != 0){
                            $resVal = (int)$resVal;
                            if($resVal != 0){
                                $resVal = "";
                                for($i=0; $i<5; $i++){
                                    $resVal .= $numberArray[mt_rand(0, 9)];
                                }
                            }
                            else{
                                $resVal = "";
                                for($i=0; $i<10; $i++){
                                    $resVal .= $symbolArray[mt_rand(0, 25)];
                                }
                            }
                        }
                        $sql = "SELECT COUNT(*) FROM " . $this->table . " WHERE " . $keyVal . " = '" . $resVal . "'";
                        $sqlRes = mysqli_query($this->connection, $sql);
                        $item = mysqli_fetch_row($sqlRes);
                    }
                    while($item[0] != 0);
                }
                if($key == "Extra" && $value != "auto_increment"){
                    $arVal[$keyVal] = $resVal;
                }
            }
        }
        return ($arVal);
    }
}