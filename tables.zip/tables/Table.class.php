<?php
class Table{
    public $connection;
    public $table;
    public $columns;

    function __construct($table, $connection){
        $this->connection = $connection;
        $this->table = $table;
    }

    function getInfo(){
        $sqlColumns = "SHOW COLUMNS FROM $this->table";
        $resColumns = mysqli_query($this->connection, $sqlColumns);
        while($item = mysqli_fetch_assoc($resColumns)){
            $this->columns[] = $item;
        }
    }
}