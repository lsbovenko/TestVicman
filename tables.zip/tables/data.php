<?php
header('Content-Type: text/html; charset=utf-8');

require("CurrentTable.class.php");

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $host = trim(strip_tags($_POST["host"]));
    $login = trim(strip_tags($_POST["login"]));
    $password = trim(strip_tags($_POST["password"]));
    $base = trim(strip_tags($_POST["base"]));
    $table = trim(strip_tags($_POST["table"]));

    $dataObj = new CurrentTable($host, $login, $password, $base);
    $dataObj->getValues($table);
}
?>

<html>
    <head>
    </head>
    <body>

        <?php if($_SERVER["REQUEST_METHOD"] == "POST"): ?>
        <?php if($dataObj->values == null): ?>
            <?="Таблица " . $table . " пустая"; ?>
            <?php exit; ?>
        <?php endif; ?>
        <table border="1">
            <caption><?="Таблица: " . $table; ?></caption>
            <?php foreach($dataObj->values as $value): ?>
            <tr>
                <?php foreach($value as $v): ?>
                <td><?=$v; ?></td>
                <?php endforeach; ?>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>

    </body>
</html>