<?php
class CurrentTable{
    public $connection;
    public $values;

    function __construct($host, $login, $password, $base){
        $this->connection = mysqli_connect($host, $login, $password, $base);
    }

    function getValues($table){
        $sqlValues = "SELECT * FROM $table";
        $resValues = mysqli_query($this->connection, $sqlValues);
        while($item = mysqli_fetch_assoc($resValues)){
            $this->values[] = $item;
        }
    }

    function setValues($table, $number){
        $generateObj = new MyGenerator($this->connection, $table);
        for($i=0; $i<$number; $i++){
            $resArr = $generateObj->generate();
            $sqlInsert  = "INSERT INTO $table";
            $sqlInsert .= " (".implode(", ", array_keys($resArr)).")";
            $sqlInsert .= " VALUES ('".implode("', '", $resArr)."') ";
            $resInsert = mysqli_query($this->connection, $sqlInsert);
        }
        return($resInsert);
    }

    function __destruct(){
        mysqli_close($this->connection);
    }
}