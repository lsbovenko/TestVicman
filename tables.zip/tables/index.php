<?php
header('Content-Type: text/html; charset=utf-8');

require("Base.class.php");
require("Table.class.php");

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $host = trim(strip_tags($_POST["host"]));
    $login = trim(strip_tags($_POST["login"]));
    $password = trim(strip_tags($_POST["password"]));
    $base = trim(strip_tags($_POST["base"]));

    $baseObj = new Base($host, $login, $password, $base);
    $baseObj->getTables();

    foreach($baseObj->tables as $table){
        $table->getInfo();
    }
}
?>

<html>
<head>
</head>
<body>

<form action="<?php $_SERVER["PHP_SELF"]?>" method="post">
    <p><b>Введите информацию о соединении с БД</b></p>
    <p><input type="text" name="host" value="">Сервер БД</p>
    <p><input type="text" name="login" value="">Логин</p>
    <p><input type="text" name="password" value="">Пароль</p>
    <p><input type="text" name="base" value="">Имя БД</p>
    <p><input type="submit"></p>
</form>

<?php if($_SERVER["REQUEST_METHOD"] == "POST"): ?>
    <?php foreach($baseObj->tables as $table): ?>
        <?php foreach($table as $key=>$value): ?>
            <?php if($key == "table"): ?>

                <?php $tableArray[] = $value; ?>

                <table border="1">
                <caption><?="Таблица: " . $value; ?></caption>
                <tr>
                    <th>Field</th>
                    <th>Type</th>
                    <th>Null</th>
                    <th>Key</th>
                    <th>Default</th>
                    <th>Extra</th>
                </tr>
            <?php endif; ?>
            <?php if($key == "columns"): ?>
                <?php foreach($value as $item): ?>
                    <tr>
                        <?php foreach($item as $v): ?>
                            <td><?=$v; ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        <?php endforeach; ?>
        <br>
    <?php endforeach; ?>
    </table>

    <br>
    <form action="data.php" method="post" target="_blank">
        <p><b>Выберите таблицу для просмотра</b></p>
        <input type="hidden" name="host" value="<?=$host?>">
        <input type="hidden" name="login" value="<?=$login?>">
        <input type="hidden" name="password" value="<?=$password?>">
        <input type="hidden" name="base" value="<?=$base?>">

        <p><select size="1" name="table">
                <?php foreach($tableArray as $table): ?>
                    <option value="<?=$table?>"><?=$table?></option>
                <?php endforeach; ?>
        </select></p>

        <p><input type="submit"></p>
    </form>

    <br>
    <form action="generate.php" method="post" target="_blank">
        <p><b>Выберите таблицу для генерации и укажите количество генерируемых строк</b></p>
        <input type="hidden" name="host" value="<?=$host?>">
        <input type="hidden" name="login" value="<?=$login?>">
        <input type="hidden" name="password" value="<?=$password?>">
        <input type="hidden" name="base" value="<?=$base?>">

        <p><select size="1" name="table">
                <?php foreach($tableArray as $table): ?>
                    <option value="<?=$table?>"><?=$table?></option>
                <?php endforeach; ?>
        </select></p>
        <p><input type="text" name="number" value=""></p>

        <p><input type="submit"></p>
    </form>

<?php endif; ?>

</body>
</html>