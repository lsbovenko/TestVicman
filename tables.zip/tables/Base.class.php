<?php
class Base{
    public $connection;
    public $base;
    public $tables;

    function __construct($host, $login, $password, $base){
        $this->base = $base;
        $this->connection = @mysqli_connect($host, $login, $password, $base) or die("Не возможно соединиться с базой");
    }

    function getTables(){
        $sqlTables = "SHOW TABLES FROM $this->base";
        $resTables = mysqli_query($this->connection, $sqlTables);
        while($item = mysqli_fetch_row($resTables)){
            $this->tables[] = new Table($item[0], $this->connection);
        }
    }
}